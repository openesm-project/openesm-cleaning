#################################################################
##################   LIBRARIES AND FUNCTIONS ####################
#################################################################
rm(list=ls())

library(psych)
library(glmnet)
library(Hmisc)
library(fmsb)
library(DataCombine)
library(qgraph)
library(pROC)
library(reshape2)
source('beepday2consec.R', encoding = 'UTF-8')
source('lagData.R', encoding = 'UTF-8')

#See external .R files for 'beepday2consec' and 'lagData' functions
#Taken from mgm mvar internal code

#################################################################
##################  DATA SETUP AND CLEANING #####################
#################################################################

#Read in data
dataL0 <- read.csv('n.drink.L0.csv',as.is=TRUE)
dataL1 <- read.csv('n.drink.L1.csv',as.is=TRUE)
dataL0 <- dataL0[,-1]
dataL1 <- dataL1[,-1]

## Training/Testing ##
## 50% of the sample size
smp_size <- floor(0.5 * nrow(dataL0))

#Create random sets of 50% each
##set the seed to make your partition reproducible
set.seed(8675309)
train_ind <- sample(seq_len(nrow(dataL0)), size = smp_size)

#Training and testing sets
trainL0 <- dataL0[train_ind, ]
testL0 <- dataL0[-train_ind, ]
trainL1 <- dataL1[train_ind, ]
testL1 <- dataL1[-train_ind, ]

######################################
########  Drinking Events  ###########
######################################

#Prediction variables/Prediction matrices (feature space)
#Vars from datyL1 are lagged, vars from datyL0 are contemporaneous with DV
#Psychosocial variables (left side) + time variables (right side)
trainmat = data.matrix(cbind(trainL1[,c(4:18,26)],trainL0[,c(29:35,37:53)]))
testmat = data.matrix(cbind(testL1[,c(4:18,26)],testL0[,c(29:35,37:53)]))

set.seed(8675309)
reg1=cv.glmnet(trainmat,trainL0$drinkbin,family='binomial',standardize=T,alpha=.5)
coef1=coef(reg1, s = "lambda.min")
coef1

pred1=predict(reg1, newx=testmat, s = "lambda.min", type = "link")
testL0$regpred1=as.numeric(pred1)
pROC::auc(pROC::roc(testL0$drinkbin~testL0$regpred1))
#0.81
pROC::coords((pROC::roc(testL0$drinkbin~testL0$regpred1)),"best", ret=c("threshold", "specificity", "sensitivity"), transpose=FALSE)
#threshold   specificity    sensitivity
# -1.641633   0.8427948        0.65
pred.prob1 <- predict(reg1, newx=testmat, s = "lambda.min", type = "response")
brierScore1 <- mean((pred.prob1-as.numeric(as.character(testL0$drinkbin)))^2)
brierScore1
# 0.087


##############################
########  Craving  ###########
##############################

#Read in data
dataL0 <- read.csv('n.crave.L0.csv',as.is=TRUE)
dataL1 <- read.csv('n.crave.L1.csv',as.is=TRUE)

#selecting a random observartion to remove to have an even 50% data split
set.seed(8675309)
select<- sample(1:nrow(dataL0), 1)
dataL0 <- dataL0[-select,-1]
dataL1 <- dataL1[-select,-1]

## Training/Testing ##
## 50% of the sample size
smp_size <- floor(0.5 * nrow(dataL0))

#Create random sets of 50% each
##set the seed to make your partition reproducible
set.seed(8675309)
train_ind <- sample(seq_len(nrow(dataL0)), size = smp_size)

#Training and testing sets
trainL0 <- dataL0[train_ind, ]
testL0 <- dataL0[-train_ind, ]
trainL1 <- dataL1[train_ind, ]
testL1 <- dataL1[-train_ind, ]

trainmat = data.matrix(cbind(trainL1[,c(4:18,26)],trainL0[,c(29:35,37:53)]))
testmat = data.matrix(cbind(testL1[,c(4:18,26)],testL0[,c(29:35,37:53)]))


set.seed(8675309)
reg2=cv.glmnet(trainmat,trainL0$craving,family='gaussian',standardize=T,alpha=.5)
coef2=coef(reg2, s = "lambda.min")
coef2

pred2=predict(reg2, newx=testmat, s = "lambda.min", type = "link")
testL0$regpred2=as.numeric(pred2)
(cor.test(testL0$craving,testL0$regpred2)[4]$estimate)^2
#0.52


############################################
########  I Would Like to Drink  ###########
############################################

#Read in data
dataL0 <- read.csv('n.want.L0.csv',as.is=TRUE)
dataL1 <- read.csv('n.want.L1.csv',as.is=TRUE)


dataL0 <- dataL0[-select,-1]
dataL1 <- dataL1[-select,-1]

## Training/Testing ##
## 50% of the sample size
smp_size <- floor(0.5 * nrow(dataL0))

#Create random sets of 50% each
##set the seed to make your partition reproducible
set.seed(8675309)
train_ind <- sample(seq_len(nrow(dataL0)), size = smp_size)

#Training and testing sets
trainL0 <- dataL0[train_ind, ]
testL0 <- dataL0[-train_ind, ]
trainL1 <- dataL1[train_ind, ]
testL1 <- dataL1[-train_ind, ]

trainmat = data.matrix(cbind(trainL1[,c(4:18,26)],trainL0[,c(29:35,37:53)]))
testmat = data.matrix(cbind(testL1[,c(4:18,26)],testL0[,c(29:35,37:53)]))

set.seed(8675309)
reg3=cv.glmnet(trainmat,trainL0$wantdrink,family='gaussian',standardize=T,alpha=.5)
coef3=coef(reg3, s = "lambda.min")
coef3

pred3=predict(reg3, newx=testmat, s = "lambda.min", type = "link")
testL0$regpred3=as.numeric(pred3)
r2<- (cor.test(testL0$wantdrink,testL0$regpred3)[4]$estimate)^2
#0.60
 
