#################################################################
##################   LIBRARIES AND FUNCTIONS ####################
#################################################################
rm(list=ls(  ))
library(psych)
#################################################################
##################  DATA SETUP AND CLEANING #####################
#################################################################

#Read in data
data <- read.csv("n.full.results.csv")


####################################################
###Comparing idiographic model to pooled model### 
####################################################

#test for AUC
t.test(data$i.auc,
       data$new.auc,
       paired=TRUE,
       conf.level=0.95) #not sig different

#test for Specificity
t.test(data$i.spec,
       data$new.spec,
       paired=TRUE,
       conf.level=0.95) #not sig different

#test for Sensitivity
t.test(data$i.sens,
       data$new.sens,
       paired=TRUE,
       conf.level=0.95) # not sig different

#test for Brier
t.test(data$i.brier,
       data$new.brier,
       paired=TRUE,
       conf.level=0.95) # not sig different

#test for R2 craving
t.test(data$i.r2.crave,
       data$new.r2.crave,
       paired=TRUE,
       conf.level=0.95) # nomo/idio significantly better

#test for R2 wanting
t.test(data$i.r2.want,
       data$new.r2.want,
       paired=TRUE,
       conf.level=0.95) #nomo/idio significantly better

########################################
###Comparing idiographic model to MLM### 
########################################

#test for AUC
t.test(data$i.auc,
       data$mlm.auc,
       paired=TRUE,
       conf.level=0.95) #not sig different

#test for Specificity
t.test(data$i.spec,
       data$mlm.spec,
       paired=TRUE,
       conf.level=0.95) #not sig different

#test for Sensitivity
t.test(data$i.sens,
       data$mlm.sens,
       paired=TRUE,
       conf.level=0.95) # not sig different

#test for Brier
t.test(data$i.brier,
       data$mlm.brier,
       paired=TRUE,
       conf.level=0.95) # not sig different

#test for R2 craving
t.test(data$i.r2.crave,
       data$mlm.r2.crave,
       paired=TRUE,
       conf.level=0.95) # MLM significantly better

#test for R2 wanting
t.test(data$i.r2.want,
       data$mlm.r2.want,
       paired=TRUE,
       conf.level=0.95) #MLM significantly better

###################################
###Comparing pooled model to MLM### 
###################################

#test for AUC
t.test(data$new.auc,
       data$mlm.auc,
       paired=TRUE,
       conf.level=0.95) #not sig different

#test for Specificity
t.test(data$new.spec,
       data$mlm.spec,
       paired=TRUE,
       conf.level=0.95) #not sig different

#test for Sensitivity
t.test(data$new.sens,
       data$mlm.sens,
       paired=TRUE,
       conf.level=0.95) # not sig different

#test for Brier
t.test(data$new.brier,
       data$mlm.brier,
       paired=TRUE,
       conf.level=0.95) # not sig different

#test for R2 craving
t.test(data$new.r2.crave,
       data$mlm.r2.crave,
       paired=TRUE,
       conf.level=0.95) # not sig different
#test for R2 wanting
t.test(data$new.r2.want,
       data$mlm.r2.want,
       paired=TRUE,
       conf.level=0.95) #pooled significantly better

###########################
### Exploratory Analyses###
###########################

###############
##Idiographic##
###############
#checking to see if any demographic variables predict idio AUC

summary(lm(data$i.auc ~data$Age))
# no for age

summary(lm(data$i.auc ~data$Gender))
# no for gender

summary(lm(data$i.auc ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$i.auc~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$i.auc ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$i.auc ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$i.auc ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$i.auc ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$i.auc ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$i.auc ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$i.auc ~as.factor(data$stim)))
# no for stim use

summary(lm(data$i.auc ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict idio spec

summary(lm(data$i.spec ~data$Age))
# no for age

summary(lm(data$i.spec ~data$Gender))
# no for gender

summary(lm(data$i.spec ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$i.spec~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$i.spec ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$i.spec ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$i.spec ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$i.spec ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$i.spec ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$i.spec ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$i.spec~as.factor(data$stim)))
# no for stim use

summary(lm(data$i.spec ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict idio sens

summary(lm(data$i.sens ~data$Age))
# no for age

summary(lm(data$i.sens ~data$Gender))
# no for gender

summary(lm(data$i.sens ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$i.sens~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$i.sens ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$i.sens ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$i.sens ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$i.sens ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$i.sens ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$i.sens ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$i.sens~as.factor(data$stim)))
# no for stim use

summary(lm(data$i.sens ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict idio brier

summary(lm(data$i.brier ~data$Age))
# no for age

summary(lm(data$i.brier ~data$Gender))
# Males have significantly better brier scores

summary(lm(data$i.brier ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$i.brier~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$i.brier ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$i.brier ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$i.brier ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$i.brier ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$i.brier ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$i.brier ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$i.brier~as.factor(data$stim)))
# no for stim use

summary(lm(data$i.brier ~as.factor(data$drug.poly)))
# no for poly use



####checking to see if any demographic variables predict idio r2 crave

summary(lm(data$i.r2.crave ~data$Age))
# no for age

summary(lm(data$i.r2.crave ~data$Gender))
# no for gender

summary(lm(data$i.r2.crave ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$i.r2.crave~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$i.r2.crave ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$i.r2.crave ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$i.r2.crave ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$i.r2.crave ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$i.r2.crave~as.factor(data$mj)))
# no for MJ use

summary(lm(data$i.r2.crave ~as.factor(data$halluc)))
# sig higher for halluc use

summary(lm(data$i.r2.crave~as.factor(data$stim)))
# sig higher for stim use

summary(lm(data$i.r2.crave ~as.factor(data$drug.poly)))
# sig higher for poly use

####checking to see if any demographic variables predict idio r2 want

summary(lm(data$i.r2.want ~data$Age))
# no for age

summary(lm(data$i.r2.want ~data$Gender))
# no for gender

summary(lm(data$i.r2.want ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$i.r2.want~data$Mean.Days.Drinking.Per.Week))
# sig diff for M drinking days per week

summary(lm(data$i.r2.want ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$i.r2.want ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$i.r2.want ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$i.r2.want ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$i.r2.want~as.factor(data$mj)))
# no for MJ use

summary(lm(data$i.r2.want ~as.factor(data$halluc)))
# sig higher for halluc use

summary(lm(data$i.r2.want~as.factor(data$stim)))
# sig higher for stim use

summary(lm(data$i.r2.want ~as.factor(data$drug.poly)))
# no for poly use

##########
##pooled##
##########
#checking to see if any demographic variables predict pooled AUC

summary(lm(data$new.auc ~data$Age))
# no for age

summary(lm(data$new.auc ~data$Gender))
# no for gender

summary(lm(data$new.auc ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$new.auc~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$new.auc ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$new.auc ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$new.auc ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$new.auc ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$new.auc ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$new.auc ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$new.auc ~as.factor(data$stim)))
# no for stim use

summary(lm(data$new.auc ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict pooled spec

summary(lm(data$new.spec ~data$Age))
# no for age

summary(lm(data$new.spec ~data$Gender))
# no for gender

summary(lm(data$new.spec ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$new.spec~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$new.spec ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$new.spec ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$new.spec ~data$surveys.completed))
# YES for # of surveys completed

summary(lm(data$new.spec ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$new.spec ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$new.spec ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$new.spec~as.factor(data$stim)))
# no for stim use

summary(lm(data$new.spec ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict pooled sens

summary(lm(data$new.sens ~data$Age))
# no for age

summary(lm(data$new.sens ~data$Gender))
# no for gender

summary(lm(data$new.sens ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$new.sens~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$new.sens ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$new.sens ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$new.sens ~data$surveys.completed))
# YES for # of surveys completed

summary(lm(data$new.sens~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$new.sens ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$new.sens ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$new.sens~as.factor(data$stim)))
# no for stim use

summary(lm(data$new.sens ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict pooled brier

summary(lm(data$new.brier ~data$Age))
# no for age

summary(lm(data$new.brier ~data$Gender))
# Males have significantly better brier scores

summary(lm(data$new.brier ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$new.brier~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$new.brier ~data$Mean.Drinks.Per.Drinking.Occasion))
# YES for M drinks per drinking occasion

summary(lm(data$new.brier ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$new.brier ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$new.brier ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$new.brier ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$new.brier ~as.factor(data$halluc)))
# YES no for halluc use

summary(lm(data$new.brier~as.factor(data$stim)))
# YES for stim use

summary(lm(data$new.brier ~as.factor(data$drug.poly)))
# YES for poly use


####checking to see if any demographic variables predict pooled r2 crave

summary(lm(data$new.r2.crave ~data$Age))
# no for age

summary(lm(data$new.r2.crave ~data$Gender))
# no for gender

summary(lm(data$new.r2.crave ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$new.r2.crave~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$new.r2.crave~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$new.r2.crave ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$new.r2.crave ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$new.r2.crave ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$new.r2.crave~as.factor(data$mj)))
# YES for MJ use

summary(lm(data$new.r2.crave ~as.factor(data$halluc)))
# sig higher for halluc use

summary(lm(data$new.r2.crave~as.factor(data$stim)))
# no for stim use

summary(lm(data$new.r2.crave ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict pooled r2 want

summary(lm(data$new.r2.want ~data$Age))
# no for age

summary(lm(data$new.r2.want ~data$Gender))
# no for gender

summary(lm(data$new.r2.want ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$new.r2.want~data$Mean.Days.Drinking.Per.Week))
# sig diff for M drinking days per week

summary(lm(data$new.r2.want ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$new.r2.want ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$new.r2.want ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$new.r2.want ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$new.r2.want~as.factor(data$mj)))
# no for MJ use

summary(lm(data$new.r2.want ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$new.r2.want~as.factor(data$stim)))
# no for stim use

summary(lm(data$new.r2.want ~as.factor(data$drug.poly)))
# no for poly use

#########
###MLM###
#########
#checking to see if any demographic variables predict mlm AUC

summary(lm(data$mlm.auc ~data$Age))
# no for age

summary(lm(data$mlm.auc ~data$Gender))
# no for gender

summary(lm(data$mlm.auc ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$mlm.auc~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$mlm.auc ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$mlm.auc ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$mlm.auc ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$mlm.auc ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$mlm.auc ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$mlm.auc ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$mlm.auc ~as.factor(data$stim)))
# no for stim use

summary(lm(data$mlm.auc ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict mlm spec

summary(lm(data$mlm.spec ~data$Age))
# no for age

summary(lm(data$mlm.spec ~data$Gender))
# no for gender

summary(lm(data$mlm.spec ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$mlm.spec~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$mlm.spec ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$mlm.spec ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$mlm.spec ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$mlm.spec ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$mlm.spec ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$mlm.spec ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$mlm.spec~as.factor(data$stim)))
# no for stim use

summary(lm(data$mlm.spec ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict mlm sens

summary(lm(data$mlm.sens ~data$Age))
# no for age

summary(lm(data$mlm.sens ~data$Gender))
# no for gender

summary(lm(data$mlm.sens ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$mlm.sens~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$mlm.sens ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$mlm.sens ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$mlm.sens ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$mlm.sens~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$mlm.sens ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$mlm.sens ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$mlm.sens~as.factor(data$stim)))
# no for stim use

summary(lm(data$mlm.sens ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict mlm brier

summary(lm(data$mlm.brier ~data$Age))
# no for age

summary(lm(data$mlm.brier ~data$Gender))
# no for gender

summary(lm(data$mlm.brier ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$mlm.brier~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$mlm.brier ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$mlm.brier ~data$Age.of.First.Drink))
# no for age of first drink

summary(lm(data$mlm.brier ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$mlm.brier ~data$drinking.occasions))
# YES for # of drinking occasions

summary(lm(data$mlm.brier ~as.factor(data$mj)))
# no for MJ use

summary(lm(data$mlm.brier ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$mlm.brier~as.factor(data$stim)))
# no for stim use

summary(lm(data$mlm.brier ~as.factor(data$drug.poly)))
# no for poly use


####checking to see if any demographic variables predict mlm r2 crave

summary(lm(data$mlm.r2.crave ~data$Age))
# no for age

summary(lm(data$mlm.r2.crave ~data$Gender))
# no for gender

summary(lm(data$mlm.r2.crave ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$mlm.r2.crave~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$mlm.r2.crave~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$mlm.r2.crave ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$mlm.r2.crave ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$mlm.r2.crave ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$mlm.r2.crave~as.factor(data$mj)))
# no for MJ use

summary(lm(data$mlm.r2.crave ~as.factor(data$halluc)))
# no for halluc
summary(lm(data$mlm.r2.crave~as.factor(data$stim)))
# no for stim use

summary(lm(data$mlm.r2.crave ~as.factor(data$drug.poly)))
# no for poly use

####checking to see if any demographic variables predict MLM r2 want

summary(lm(data$mlm.r2.want ~data$Age))
# no for age

summary(lm(data$mlm.r2.want ~data$Gender))
# no for gender

summary(lm(data$mlm.r2.want ~as.factor(data$Sexual.Orientation)))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(lm(data$mlm.r2.want~data$Mean.Days.Drinking.Per.Week))
# no for M drinking days per week

summary(lm(data$mlm.r2.want ~data$Mean.Drinks.Per.Drinking.Occasion))
# no for M drinks per drinking occasion

summary(lm(data$mlm.r2.want ~data$Age.of.First.Drink))
# no for age of first drink

summary(glm(data$mlm.r2.want ~data$surveys.completed))
# no for # of surveys completed

summary(lm(data$mlm.r2.want ~data$drinking.occasions))
# no for # of drinking occasions

summary(lm(data$mlm.r2.want~as.factor(data$mj)))
# no for MJ use

summary(lm(data$mlm.r2.want ~as.factor(data$halluc)))
# no for halluc use

summary(lm(data$new.r2.want~as.factor(data$stim)))
# no for stim use

summary(lm(data$mlm.r2.want ~as.factor(data$drug.poly)))
# no for poly use


##############################################################
###When does pooled model do better than idiographic model?###
##############################################################

#############
###For AUC###
#############

diff.auc=data$i.auc - data$new.auc
data$new.auc.better[(diff.auc)<=0] <- 1
data$new.auc.better[(diff.auc)>0] <- 0
data$new.auc.better[is.na(diff.auc)==T] <- NA

sum(data$new.auc.better, na.rm=T)
(sum(data$new.auc.better, na.rm=T))/sum(!is.na(data$new.auc.better))
round(mean((diff.auc[data$new.auc.better==1]),na.rm=T),2) 
round(sd((diff.auc[data$new.auc.better==1]),na.rm=T),2) 
# 8 people (42%) of the sample (for whom an AUC was estimated idiographically)
# had better AUC with pooled model. The average improvement in AUC was 0.08 (sd=0.06)


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$new.auc.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$new.auc.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$new.auc.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$new.auc.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$new.auc.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$new.auc.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$new.auc.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$new.auc.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$new.auc.better ~as.factor(data$mj), family="binomial"))
# no for MJ use

summary(glm(data$new.auc.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$new.auc.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$new.auc.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

#####################
###For Specificity###
#####################
diff.spec=data$i.spec - data$new.spec
data$new.spec.better[(diff.spec)<=0] <- 1
data$new.spec.better[(diff.spec)>0] <- 0
data$new.spec.better[is.na(data$i.spec - data$new.spec)==T] <- NA

sum(data$new.spec.better, na.rm=T)
(sum(data$new.spec.better, na.rm=T))/sum(!is.na(data$new.spec.better))
round(mean((data$diff.spec[data$new.spec.better==1]),na.rm=T),2) 
round(sd((data$diff.spec[data$new.spec.better==1]),na.rm=T),2) 
# 12 people (67%) of the sample (for whom a spec was estimated idiographically)
# had better spec with pooled model. The average improvement in spec was 0.16 (sd=0.27)


#checking to see if any demographic variables predict who will do better with pooled model

summary(glm(data$new.spec.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$new.spec.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$new.spec.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$new.spec.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$new.spec.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$new.spec.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$new.spec.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$new.spec.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$new.spec.better ~as.factor(data$mj), family="binomial"))
# no for MJ use

summary(glm(data$new.spec.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$new.spec.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$new.spec.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use


#####################
###For Sensitivity###
#####################
diff.sens=data$i.sens - data$new.sens
data$new.sens.better[(diff.sens)<=0] <- 1
data$new.sens.better[(diff.sens)>0] <- 0
data$new.sens.better[is.na(data$i.sens - data$new.sens)==T] <- NA

sum(data$new.sens.better, na.rm=T)
(sum(data$new.sens.better, na.rm=T))/sum(!is.na(data$new.sens.better))
round(mean((diff.sens[data$new.sens.better==1]),na.rm=T),2) 
round(sd((diff.sens[data$new.sens.better==1]),na.rm=T),2) 
# 14 people (78%) of the sample (for whom a sens was estimated idiographically)
# had better sens with pooled model. The average improvement in sens was 0.06 (sd=0.18)


#checking to see if any demographic variables predict who will do better with pooled model

summary(glm(data$new.sens.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$new.sens.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$new.sens.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$new.sens.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$new.sens.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$new.sens.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$new.sens.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$new.sens.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$new.sens.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$new.sens.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$new.sens.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$new.sens.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

###############
###For Brier###
###############
diff.brier= data$new.brier -data$i.brier
data$new.brier.better[(diff.brier)<=0] <- 1
data$new.brier.better[(diff.brier)>0] <- 0
data$new.brier.better[is.na(data$i.brier - data$new.brier)==T] <- NA


sum(data$new.brier.better, na.rm=T)
(sum(data$new.brier.better, na.rm=T))/sum(!is.na(data$new.brier.better))
round(mean((diff.brier[data$n.brier.better==1]),na.rm=T),2) 
round(sd((diff.brier[data$n.brier.better==1]),na.rm=T),2) 
# 12 people (63%) of the sample (for whom a brier was estimated idiographically)
# had better breir with pooled model. The average improvement in brier was 0.02 (sd=0.03)


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$new.brier.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$new.brier.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$new.brier.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$new.brier.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$new.brier.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$new.brier.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$new.brier.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$new.brier.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$new.brier.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$new.brier.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$new.brier.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$new.brier.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

#################
###For Craving###
#################
diff.crave= data$i.r2.crave -data$new.r2.crave
data$new.crave.better[(diff.crave)<=0] <- 1
data$new.crave.better[(diff.crave)>0] <- 0
data$new.crave.better[is.na(data$i.r2.crave - data$new.r2.crave)==T] <- NA

sum(data$new.crave.better, na.rm=T)
(sum(data$new.crave.better, na.rm=T))/sum(!is.na(data$new.crave.better))
round(mean((diff.crave[data$new.crave.better==1]),na.rm=T),2) 
round(sd((diff.crave[data$new.crave.better==1]),na.rm=T),2) 
# 22 people (79%) of the sample (for whom an craving r2 was estimated idiographically)
# had better r2 with pooled model. The average improvement in r2 was 0.01 (sd=0.08)


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$new.crave.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$new.crave.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$new.crave.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$new.crave.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$new.crave.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$new.crave.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$new.crave.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$new.crave.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$new.crave.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$new.crave.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$new.crave.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$new.crave.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

#################
###For Wanting###
#################
diff.want= data$i.r2.want -data$new.r2.want
data$new.want.better[(diff.want)<=0] <- 1
data$new.want.better[(diff.want)>0] <- 0
data$new.want.better[is.na(data$i.r2.want - data$new.r2.want)==T] <- NA

sum(data$new.want.better, na.rm=T)
(sum(data$new.want.better, na.rm=T))/sum(!is.na(data$new.want.better))
round(mean((diff.want[data$new.want.better==1]),na.rm=T),2) 
round(sd((diff.want[data$new.want.better==1]),na.rm=T),2) 
# 17 people (63%) of the sample (for whom an wanting r2 was estimated idiographically)
# had better r2 with pooled model. The average improvement in r2 was 0.14 (sd=0.07)


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$new.want.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$new.want.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$new.want.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$new.want.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$new.want.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$new.want.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$new.want.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$new.want.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$new.want.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$new.want.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$new.want.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$new.want.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

#####################################################
###When does MLM do better than idiographic model?###
#####################################################

#############
###For AUC###
#############

diff.auc=data$i.auc - data$mlm.auc
data$mlm.auc.better[(diff.auc)<=0] <- 1
data$mlm.auc.better[(diff.auc)>0] <- 0
data$mlm.auc.better[is.na(diff.auc)==T] <- NA

sum(data$mlm.auc.better, na.rm=T)
(sum(data$mlm.auc.better, na.rm=T))/sum(!is.na(data$mlm.auc.better))
round(mean((diff.auc[data$mlm.auc.better==1]),na.rm=T),2) 
round(sd((diff.auc[data$mlm.auc.better==1]),na.rm=T),2) 
# 8 people (42%) of the sample (for whom an AUC was estimated idiographically)
# had better AUC with mlm. The average improvement in AUC was 0.08 (sd=0.07)


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$mlm.auc.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$mlm.auc.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$mlm.auc.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$mlm.auc.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$mlm.auc.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$mlm.auc.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$mlm.auc.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$mlm.auc.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$mlm.auc.better ~as.factor(data$mj), family="binomial"))
# no for MJ use

summary(glm(data$mlm.auc.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$mlm.auc.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$mlm.auc.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

#####################
###For Specificity###
#####################
diff.spec=data$i.spec - data$mlm.spec
data$mlm.spec.better[(diff.spec)<=0] <- 1
data$mlm.spec.better[(diff.spec)>0] <- 0
data$mlm.spec.better[is.na(data$i.spec - data$mlm.spec)==T] <- NA

sum(data$mlm.spec.better, na.rm=T)
(sum(data$mlm.spec.better, na.rm=T))/sum(!is.na(data$mlm.spec.better))
round(mean((diff.spec[data$mlm.spec.better==1]),na.rm=T),2) 
round(sd((diff.spec[data$mlm.spec.better==1]),na.rm=T),2) 
# 12 people (63%) of the sample (for whom a spec was estimated idiographically)
# had better spec with mlm model. The average improvement in spec was 0.14 (sd=0.19)


#checking to see if any demographic variables predict who will do better with pooled model

summary(glm(data$mlm.spec.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$mlm.spec.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$mlm.spec.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$mlm.spec.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$mlm.spec.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$mlm.spec.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$mlm.spec.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$mlm.spec.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$mlm.spec.better ~as.factor(data$mj), family="binomial"))
# no for MJ use

summary(glm(data$mlm.spec.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$mlm.spec.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$mlm.spec.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use


#####################
###For Sensitivity###
#####################
diff.sens=data$i.sens - data$mlm.sens
data$mlm.sens.better[(diff.sens)<=0] <- 1
data$mlm.sens.better[(diff.sens)>0] <- 0
data$mlm.sens.better[is.na(data$i.sens - data$mlm.sens)==T] <- NA

sum(data$mlm.sens.better, na.rm=T)
(sum(data$mlm.sens.better, na.rm=T))/sum(!is.na(data$mlm.sens.better))
round(mean((diff.sens[data$mlm.sens.better==1]),na.rm=T),2) 
round(sd((diff.sens[data$mlm.sens.better==1]),na.rm=T),2) 
# 13 people (68%) of the sample (for whom a sens was estimated idiographically)
# had better sens with mlm. The average improvement in sens was 0.09 (sd=0.22)


#checking to see if any demographic variables predict who will do better with pooled model

summary(glm(data$mlm.sens.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$mlm.sens.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$mlm.sens.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$mlm.sens.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$mlm.sens.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$mlm.sens.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$mlm.sens.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$mlm.sens.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$mlm.sens.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$mlm.sens.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$mlm.sens.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$mlm.sens.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

###############
###For Brier###
###############
diff.brier= data$mlm.brier -data$i.brier
data$mlm.brier.better[(diff.brier)<=0] <- 1
data$mlm.brier.better[(diff.brier)>0] <- 0
data$mlm.brier.better[is.na(data$i.brier - data$mlm.brier)==T] <- NA


sum(data$mlm.brier.better, na.rm=T)
(sum(data$mlm.brier.better, na.rm=T))/sum(!is.na(data$mlm.brier.better))
round(mean((diff.brier[data$n.brier.better==1]),na.rm=T),2) 
round(sd((diff.brier[data$n.brier.better==1]),na.rm=T),2) 
# 11 people (58%) of the sample (for whom a brier was estimated idiographically)
# had better breir with pooled model.


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$mlm.brier.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$mlm.brier.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$mlm.brier.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$mlm.brier.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$mlm.brier.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$mlm.brier.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$mlm.brier.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$mlm.brier.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$mlm.brier.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$mlm.brier.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$mlm.brier.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$mlm.brier.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

#################
###For Craving###
#################
diff.crave= data$i.r2.crave -data$mlm.r2.crave
data$mlm.crave.better[(diff.crave)<=0] <- 1
data$mlm.crave.better[(diff.crave)>0] <- 0
data$mlm.crave.better[is.na(data$i.r2.crave - data$mlm.r2.crave)==T] <- NA

sum(data$mlm.crave.better, na.rm=T)
(sum(data$mlm.crave.better, na.rm=T))/sum(!is.na(data$mlm.crave.better))
round(mean((diff.crave[data$mlm.crave.better==1]),na.rm=T),2) 
round(sd((diff.crave[data$mlm.crave.better==1]),na.rm=T),2) 
# 21 people (75%) of the sample (for whom an craving r2 was estimated idiographically)
# had better r2 with pooled model. The average improvement in r2 was 0.01 (sd=0.08)


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$mlm.crave.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$mlm.crave.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$mlm.crave.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$mlm.crave.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$mlm.crave.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$mlm.crave.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$mlm.crave.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$mlm.crave.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$mlm.crave.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$mlm.crave.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$mlm.crave.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$mlm.crave.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

#################
###For Wanting###
#################
diff.want= data$i.r2.want -data$mlm.r2.want
data$mlm.want.better[(diff.want)<=0] <- 1
data$mlm.want.better[(diff.want)>0] <- 0
data$mlm.want.better[is.na(data$i.r2.want - data$mlm.r2.want)==T] <- NA

sum(data$mlm.want.better, na.rm=T)
(sum(data$mlm.want.better, na.rm=T))/sum(!is.na(data$mlm.want.better))
round(mean((diff.want[data$mlm.want.better==1]),na.rm=T),2) 
round(sd((diff.want[data$mlm.want.better==1]),na.rm=T),2) 
# 17 people (63%) of the sample (for whom an wanting r2 was estimated idiographically)
# had better r2 with pooled model. The average improvement in r2 was 0.11 (sd=0.08)


#checking to see if any demographic variables predict who will do better with nomothetic model

summary(glm(data$mlm.want.better ~data$Age, family="binomial"))
# no for age

summary(glm(data$mlm.want.better ~data$Gender, family="binomial"))
# no for gender

summary(glm(data$mlm.want.better ~as.factor(data$Sexual.Orientation), family="binomial"))
#note: 0= heterosexual, 1= homosexual, 2= bisexual/queer
# no for sexual orientation

summary(glm(data$mlm.want.better ~data$Mean.Days.Drinking.Per.Week, family="binomial"))
# no for M drinking days per week

summary(glm(data$mlm.want.better ~data$Mean.Drinks.Per.Drinking.Occasion, family="binomial"))
# no for M drinks per drinking occasion

summary(glm(data$mlm.want.better ~data$Age.of.First.Drink, family="binomial"))
# no for age of first drink

summary(glm(data$mlm.want.better ~data$surveys.completed, family="binomial"))
# no for # of surveys completed

summary(glm(data$mlm.want.better ~data$drinking.occasions, family="binomial"))
# no for # of drinking occasions

summary(glm(data$mlm.want.better ~as.factor(data$mj), family="binomial"))
# no fo mj

summary(glm(data$mlm.want.better ~as.factor(data$halluc), family="binomial"))
# no for halluc use

summary(glm(data$mlm.want.better ~as.factor(data$stim), family="binomial"))
# no for stim use

summary(glm(data$mlm.want.better ~as.factor(data$drug.poly), family="binomial"))
# no for poly use

