

############################################################################
# Code to process EMA data for SEM

lagpad <- function(x, k) {
  c(rep(NA, k), x)[1 : length(x)] 
}  

#read datafiles into list
setwd("C:\\LabShare\\Emotion Regulation and Anxiety (Hannah)\\Data\\Week 1 Survey Data")
myfiles <- list.files(pattern = "\\.csv")
datalistW1 <- lapply(myfiles, read.csv, colClasses = c(rep("character",2),  rep("numeric", 26)))
names(datalistW1) <- gsub(" Week 1.csv", "", myfiles)


#change column names
for (i in seq_along(datalistW1)) {
  names(datalistW1[[i]]) <- c("startTime", "stopTime", "RPA1", 
                       "RPA2", "RPA3", "RPA4", "RPA5", "RPA6", 
                       "RPA7", "RPA8", "happy", "content", 
                       "excited", "sad", "depressed", "nervous", 
                       "determined", "attentive", "alert", "inspired",
                       "active", "afraid", "upset", "ashamed", "hostile",
                       "worryFreq", "worryControl", "worryInterfere")
}

#create Dampening, Worry, and PA composite variables
#NB: in the present analyses we made the a priori decision to use a three-item composite for PA, 
#     with items "happy", "excited" and "content" to reflect neutral, high, and low arousal PA
#     respectively. This is consistent with a circumplex model of PA. We did not utilize the 5-item PANAS-SF 
#     as this captures positive activation/high-arousal PA.


for (i in seq_along(datalistW1)) {
  for (j in 1:nrow(datalistW1[[i]])){
    datalistW1[[i]]$dampening[j] = sum(datalistW1[[i]]$RPA1[j],
                                        datalistW1[[i]]$RPA2[j],
                                        datalistW1[[i]]$RPA3[j],
                                        datalistW1[[i]]$RPA4[j],
                                        datalistW1[[i]]$RPA5[j],
                                        datalistW1[[i]]$RPA6[j],
                                        datalistW1[[i]]$RPA7[j],
                                        datalistW1[[i]]$RPA8[j])
    

    datalistW1[[i]]$CIRCUM.Pos[j] = sum(datalistW1[[i]]$happy[j],
                                       datalistW1[[i]]$excited[j],
                                       datalistW1[[i]]$content[j])

    
    datalistW1[[i]]$Worry[j] = sum(datalistW1[[i]]$worryFreq[j])
    
  }
}


#Create time lag and get time differences.
for (i in seq_along(datalistW1)) {
  datalistW1[[i]]$previousStart = lagpad(datalistW1[[i]]$startTime)
  datalistW1[[i]]$tdif = as.numeric(difftime(strptime(datalistW1[[i]]$startTime,"%m/%d/%Y %H:%M"),strptime(datalistW1[[i]]$previousStart,"%m/%d/%Y %H:%M")))
  datalistW1[[i]]$tdif[is.na(datalistW1[[i]]$tdif)]= 0
  datalistW1[[i]]$cumsumT=cumsum(datalistW1[[i]]$tdif)
}


#De-trend relevant items.
for (i in seq_along(datalistW1)){
  datalistW1[[i]]$worryResid=resid(lm(Worry~cumsumT, datalistW1[[i]] ,na.action=na.exclude))
  datalistW1[[i]]$dampeningResid=resid(lm(dampening~cumsumT, datalistW1[[i]] ,na.action=na.exclude))
  datalistW1[[i]]$paResid=resid(lm(CIRCUM.Pos~cumsumT, datalistW1[[i]] ,na.action=na.exclude))
}


#Create new dataframe list to store each person's cubic spline interpolation.
for (i in seq_along(datalistW1)){
  assign(sprintf("cube_%s", names(datalistW1)[i]), data.frame(worry = numeric(nrow(datalistW1[[i]])), 
                                                           dampening = numeric(nrow(datalistW1[[i]])),
                                                           pa = numeric(nrow(datalistW1[[i]]))))
  
}

dfCube = setNames(lapply(ls(pattern="cube_H[0-9]+"), function(x) get(x)), ls(pattern="cube_H[0-9]+"))


#Apply cubic spline interpolation and store new dataframes with even spacing.
for(i in seq_along(dfCube)){
  dfCube[[i]]$worry=(spline(x=datalistW1[[i]]$cumsumT, y=datalistW1[[i]]$worryResid, nrow(datalistW1[[i]]),method='fmm'))$y
  dfCube[[i]]$dampening=(spline(x=datalistW1[[i]]$cumsumT, y=datalistW1[[i]]$dampeningResid, nrow(datalistW1[[i]]),method='fmm'))$y
  dfCube[[i]]$pa=(spline(x=datalistW1[[i]]$cumsumT, y=datalistW1[[i]]$paResid, nrow(datalistW1[[i]]),method='fmm'))$y
}


#Then create final dataframes with each item duplicated and lagged twice.
for (i in 1:length(dfCube)){
  assign(sprintf("final_%s", names(datalistW1)[i]), dfCube[[i]])
}
dfFinal = setNames(lapply(ls(pattern="final_H[0-9]+"), function(x) get(x)), ls(pattern="final_H[0-9]+"))

#lag 1
for (i in seq_along(dfFinal)){
  for (j in 1:3){
    dfFinal[[i]][,j+3]=lagpad(dfFinal[[i]][,j]) #lag1
  }
}

#lag 2
for (i in seq_along(dfFinal)){
  for (j in 1:3){
    dfFinal[[i]][,j+6]=lagpad(dfFinal[[i]][,j+3]) 
  }
}
for (i in seq_along(dfFinal)) {
  names(dfFinal[[i]]) <- c("worry1", "dampening1", "pa1", "worry2", "dampening2", "pa2", "worry3", "dampening3", "pa3")
  dfFinal[[i]]=dfFinal[[i]][complete.cases(dfFinal[[i]]),]
}


#Generate covariance matrices for all people.
for (i in 1:length(dfFinal)){
  assign(sprintf("cov_%s", names(datalistW1)[i]), cov(dfFinal[[i]]))
}

#Aggregate covariance matrix for nomothetic model.
 aggregated = (cov_H001 + cov_H003 + cov_H005 + cov_H006 + cov_H007 + cov_H008 +  cov_H010 + 
               cov_H011 + cov_H013 + cov_H014 + cov_H015 + cov_H016 + cov_H017 + cov_H018 + 
               cov_H022 + cov_H023 + cov_H024 + cov_H025 + cov_H026 + cov_H027 + cov_H028 + 
               cov_H029 + cov_H030 + cov_H031 + cov_H032 + cov_H033 + cov_H034 + cov_H036 + cov_H037 + cov_H038 + 
               cov_H039 + cov_H040 + cov_H041 + cov_H042 + cov_H043 + cov_H044 + cov_H045 + cov_H046 + cov_H047 + 
               cov_H048 + cov_H049 + cov_H050 + cov_H051 + cov_H052 + cov_H053 + cov_H054 + cov_H055 + cov_H056 + 
               cov_H057 + cov_H058 + cov_H059 + cov_H060 + cov_H061 + cov_H062 + cov_H063 + cov_H064 + cov_H065 + 
               cov_H066 + cov_H067 + cov_H068 + cov_H069 + cov_H070 + cov_H071 + cov_H072 + cov_H073 + cov_H074 + 
               cov_H075 + cov_H076 + cov_H077 + cov_H078 + cov_H079 + cov_H081 + cov_H082 + cov_H083 + cov_H085 + 
               cov_H086 + cov_H087 + cov_H088 + cov_H089 + cov_H090 + cov_H091 + cov_H092 + cov_H093 + cov_H094 + 
               cov_H095 + cov_H096 + cov_H098 + cov_H099 + cov_H100 + cov_H102 + cov_H103 + cov_H104 + cov_H105 + 
               cov_H106 + cov_H107 + cov_H108)/96
 write.table(aggregated, "aggregatedCM.txt", sep=" ", row.names=F, col.names=F)


#Create within-person covariance matrices and write each to table. 
covmats = setNames(lapply(ls(pattern="cov_H[0-9]+"), function(x) get(x)), ls(pattern="cov_H[0-9]+"))
setwd("C:\\LabShare\\Emotion Regulation and Anxiety (Hannah)\\Data\\Week 1 Survey Data\\individual mediation models")
for (i in 1:length(covmats)){
  covmats[[i]][upper.tri(covmats[[i]])] = NA
  write.table(covmats[[i]], 
              file = paste0(names(covmats[i]), ".txt"),
              sep = " ",
              na = "",
              row.names = FALSE, 
              col.names = FALSE)   
}


#Create different Lisrel syntax files for each person, changing # obs and covariance matrix input.  
syntax=scan("baseLisStx.ls8", what = 'character', sep = "\n", blank.lines.skip=FALSE)

for (i in 1:length(covmats)){
  #add correct Covariance Matrix input
  syntax=gsub(pattern="cm fi='cov_H[0-9]+.txt'", 
              paste(sprintf("cm fi='cov_%s.txt'", names(datalistW1)[i])), 
              syntax)

  #add correct number of observations
  syntax=gsub(pattern="no=[0-9]+", 
              paste0("no=", as.character(nrow(datalistW1[[i]][complete.cases(datalistW1[[i]]),]))), 
              syntax)

  #save syntax file as ls8 file.
  write.table(syntax, 
             paste0(sprintf("%s_model", names(datalistW1)[i]), ".ls8"),
             row.names=FALSE,
             col.names=FALSE,
             quote=FALSE)

}


#The remaining steps as published were carried out in LISREL 8.8.