
#####################################
##### Participant 040 (2.18.19) #####
#####################################

## Read in data
data=read.csv('dat.csv',as.is=TRUE)

## Rename
names<-scan("name.txt",what = "character", sep = "\n")
colnames(data)<-names

## Duplicate and lag time
lagpad <- function(x, k) {
     c(rep(NA, k), x)[1 : length(x)] 
 }

data$lag=lagpad(data$start,1)

## Calculate time differences
data$tdif=as.numeric(difftime(strptime(data$start,"%m/%d/%Y %H:%M"),strptime(data$lag,"%m/%d/%Y %H:%M")))

## Replace NA
data$tdif[is.na(data$tdif)]<- 0

## Calculate cumulative sum of numeric elapsed time 
data$cumsumT=cumsum(data$tdif)

#plot data, inspect for outlying values
plot(data$cigs~data$cumsumT,type='o')
quantile(data$cigs,na.rm=T)

#Create dichotomous smoking variables
data$cigbin=ifelse(data$cigs>0,1,0)
data$cigH=ifelse(data$cigs>median(data$cigs,na.rm=TRUE),1,0)
length(which(data$cigbin==1)) #102
length(which(data$cigbin==0)) #8
length(which(data$cigH==1)) #42
length(which(data$cigH==0)) #68

#Trim time series to even 4obs/day
options(width=90)
data$start
nrow(data)
datx=data[,]
datx$start

#Use for internal missing rows
#library(DataCombine)
#new <- rep(NA, length(datx))
#datx <- InsertRow(datx, NewRow=new, RowNum = 120)
#nrow(datx)
#datx=datx[1:120,]
#datx$start

#Create ping variables
datx$ping=seq(0,3,1)
datx$morning=ifelse(datx$ping==0,1,0)
datx$midday=ifelse(datx$ping==1,1,0)
datx$eve=ifelse(datx$ping==2,1,0)
datx$night=ifelse(datx$ping==3,1,0)

#Code days of the week
datx$day <- rep(1:7, each=4, length.out=nrow(datx))
# 1 = Thursday (2/1/2018)
datx$mon=ifelse(datx$day==5,1,0)
datx$tues=ifelse(datx$day==6,1,0)
datx$wed=ifelse(datx$day==7,1,0)
datx$thur=ifelse(datx$day==1,1,0)
datx$fri=ifelse(datx$day==2,1,0)
datx$sat=ifelse(datx$day==3,1,0)
datx$sun=ifelse(datx$day==4,1,0)

#Temporal components (trends and cylces)
datx$linear=scale(datx$cumsumT)
datx$quad=datx$linear^2
datx$cub=datx$linear^3
datx$cos24=cos(((2*pi)/24)*datx$cumsumT)
datx$sin24=sin(((2*pi)/24)*datx$cumsumT)
datx$cos12=cos(((2*pi)/12)*datx$cumsumT)
datx$sin12=sin(((2*pi)/12)*datx$cumsumT)

## Set variables forward in time
shift<-function(x,shift_by){
  stopifnot(is.numeric(shift_by))
  stopifnot(is.numeric(x))
  
  if (length(shift_by)>1)
    return(sapply(shift_by,shift, x=x))
  
  out<-NULL
  abs_shift_by=abs(shift_by)
  if (shift_by > 0 )
    out<-c(tail(x,-abs_shift_by),rep(NA,abs_shift_by))
  else if (shift_by < 0 )
    out<-c(rep(NA,abs_shift_by), head(x,-abs_shift_by))
  else
    out<-x
  out
}

datx$cigfw=shift(datx$cigs,1)
datx$cigbinfw=ifelse(datx$cigfw>=1,1,0)
datx$cigHfw=shift(datx$cigH,1)

datx$mornfw=shift(datx$morning,1)
datx$midfw=shift(datx$midday,1)
datx$evefw=shift(datx$eve,1)
datx$nightfw=shift(datx$night,1)

datx$monfw=shift(datx$mon,1)
datx$tuesfw=shift(datx$tues,1)
datx$wedfw=shift(datx$wed,1)
datx$thursfw=shift(datx$thur,1)
datx$frifw=shift(datx$fri,1)
datx$satfw=shift(datx$sat,1)
datx$sunfw=shift(datx$sun,1)

describe(datx)
colnames(datx)

## Create filter to mark cases with missing data
datx$filter=ifelse(!complete.cases(datx[,c(3:32,62)]),1,0)

## Remove NAs, suppress row names
daty=subset(datx,filter==0)
row.names(daty)<- NULL
nrow(daty)
#99

#Required packages
library(glmnet)
library(psych)
library(Hmisc)
library(party)
library(e1071)
library(pROC)

######################################################################
#################### Prediction Models ###############################
######################################################################

daty$even=seq(0,(nrow(daty)-1),1)
plot(daty$cigs~daty$even,type='o')
plot(daty$cigbinfw~daty$even,type='o')
plot(daty$cigHfw~daty$even,type='o')

plot(daty$cigHfw[1:65]~daty$even[1:65],type='o')
plot(daty$cigHfw[66:77]~daty$even[66:77],type='o')

dat1=daty[1:65,]
dat2=daty[66:77,]

################################################################
#################### Elastic Net ###############################
################################################################

psych::describe(daty)

#Input matrices for GLMNET
mat1=as.matrix(dat1[,c(3,5:32,41,66:68,70:75,58:61)]) #yes/no
mat2=as.matrix(dat2[,c(3,5:32,41,66:68,70:75,58:61)])

#GLMNET
set.seed(1)
tmod1=cv.glmnet(mat1,dat1$cigHfw,family='binomial',standardize=TRUE,alpha=.0005,type.measure='mse')
coef1=coef(tmod1, s = "lambda.min")
coef1
#enjoy.last    -4.580982e-05
#irritable     -6.947797e-06
#concentrate   -2.006673e-05
#down          -3.017043e-05
#tired         -1.449813e-05
#hurt.health   -1.726029e-05
#want.quit      3.976209e-05
#pos.expect     2.986416e-05
#agency         3.505171e-05
#frustrated    -4.798114e-06
#pos.social     6.062731e-05
#midfw         -7.675919e-05
#evefw         -1.326428e-03
#nightfw        5.544293e-04
#tuesfw        -6.247902e-04
#thursfw        8.534480e-04
#cos24         -7.945892e-04
#sin24          .           
#cos12          .           
#sin12         -1.022503e-03 

#Training model(s)
mlpred1=predict.cv.glmnet(tmod1, newx=mat1, s = "lambda.min", type = "link")
dat1$netpred=as.numeric(mlpred1)
somers2(dat1$netpred,dat1$cigHfw)[1]
#AUC = 0.77

#Testing model(s)
mlpred2=predict.cv.glmnet(tmod1, newx=mat2, s = "lambda.min", type = "link")
dat2$netpred=as.numeric(mlpred2)
somers2(dat2$netpred,dat2$cigHfw)[1]
#AUC = 0.50

coords((roc(dat2$cigHfw~dat2$netpred)),"best", ret=c("threshold", "specificity", "sensitivity"))
#  threshold specificity sensitivity 
#-0.09452687  0.25000000  1.00000000
auc(roc(dat2$cigHfw~dat2$netpred))
#0.50

#GLM model
#Training model
lm1=glm(cigHfw~enjoy.last+irritable+concentrate+down+tired+hurt.health+want.quit+
          pos.expect+agency+frustrated+pos.social+midfw+evefw+nightfw+tuesfw+thursfw+
          frifw+cos12+sin12+cos24+sin24,dat1,family='binomial')
somers2(predict(lm1),dat1$cigHfw)[1]
#AUC = 0.90

#Testing model(s), Time 2
predfw <- predict(lm1, newdata = dat2)
somers2(predfw,dat2$cigHfw)[1]
#AUC = 0.59

coords((roc(dat2$cigHfw~predfw)),"best", ret=c("threshold", "specificity", "sensitivity"))
#                best      best      best
#threshold   4.795131 0.9092135 -3.660966
#specificity 0.250000 0.5000000  1.000000
#sensitivity 1.000000 0.7500000  0.250000   
auc(roc(dat2$cigHfw~predfw))
#0.59

################################################################
#################### Naive Bayes ###############################
################################################################

########################################################
### Naive Bayes with Random forest feature selection ###
########################################################

#Random Forest Feature Selection
nbdat=dat1[,c(64,3,5:32,41,66:68,70:75,58:61)]
nbdat$cigHfw=as.factor(nbdat$cigHfw)
set.seed(1)
cf <- cforest(cigHfw ~ ., data=nbdat, control=cforest_unbiased(mtry=2,ntree=50))
set.seed(1)
imp=varimpAUC(cf)
imp[order(imp)]
print(imp>0)

#Random Forest data subsets
t1=nbdat[,-1]
newdat1 <- t1[, (imp>0)]

t2=dat2[,c(3,5:32,41,66:68,70:75,58:61)]
newdat2 <- t2[, (imp>0)]

#Naive Bayes with RF-selected data
rfnb=naiveBayes(newdat1,nbdat$cigHfw)
rfnbpred=predict(rfnb,newdat2,type='raw')
somers2(rfnbpred[,2],dat2$cigHfw)[1]
#0.69

coords((roc(dat2$cigHfw~rfnbpred[,2])),"best", ret=c("threshold", "specificity", "sensitivity"))
#  threshold specificity sensitivity 
# 0.8453068   1.0000000   0.5000000  
auc(roc(dat2$cigHfw~rfnbpred[,2]))
#0.69

########################################################
############ Naive Bayes with Complete Data ############
########################################################

nb=naiveBayes(mat1,dat1$cigHfw)
nbpred=predict(nb,mat2,type='raw')
somers2(nbpred[,2],dat2$cigHfw)[1]
#0.63

coords((roc(dat2$cigHfw~nbpred[,2])),"best", ret=c("threshold", "specificity", "sensitivity"))
#  threshold specificity sensitivity 
#0.003532029 0.500000000 0.833333333 
auc(roc(dat2$cigHfw~nbpred[,2]))
#0.63



