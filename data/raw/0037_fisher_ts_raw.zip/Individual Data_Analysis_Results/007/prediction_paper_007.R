
#####################################
##### Participant 007 (2.15.19) #####
#####################################


## Read in data
data=read.csv('dat.csv',as.is=TRUE)

## Rename
names<-scan("name.txt",what = "character", sep = "\n")
colnames(data)<-names

## Duplicate and lag time
lagpad <- function(x, k) {
     c(rep(NA, k), x)[1 : length(x)] 
 }

data$lag=lagpad(data$start,1)

## Calculate time differences
data$tdif=as.numeric(difftime(strptime(data$start,"%m/%d/%Y %H:%M"),strptime(data$lag,"%m/%d/%Y %H:%M")))

## Replace NA
data$tdif[is.na(data$tdif)]<- 0

## Calculate cumulative sum of numeric elapsed time 
data$cumsumT=cumsum(data$tdif)

#plot data, inspect for outlying values
plot(data$cigs~data$cumsumT,type='o')
#Remove first observation
data=data[-1,]
plot(data$cigs~data$cumsumT,type='o')

#Create dichotomous smoking variables
data$cigbin=ifelse(data$cigs>0,1,0)
data$cigH=ifelse(data$cigs>median(data$cigs,na.rm=TRUE),1,0)

#Trim time series to even 4obs/day
options(width=90)
data$start
nrow(data)
datx=data[2:107,]
datx$start

#Use for internal missing rows
library(DataCombine)
new <- rep(NA, length(datx))
datx <- InsertRow(datx, NewRow=new, RowNum = 19)
datx <- InsertRow(datx, NewRow=new, RowNum = 64)
datx <- InsertRow(datx, NewRow=new, RowNum = 93)
datx <- InsertRow(datx, NewRow=new, RowNum = 94)
datx <- InsertRow(datx, NewRow=new, RowNum = 102)
datx <- InsertRow(datx, NewRow=new, RowNum = 112)
nrow(datx)
datx=datx[1:112,]
datx$start

#Create ping variables
datx$ping=seq(0,3,1)
datx$morning=ifelse(datx$ping==0,1,0)
datx$midday=ifelse(datx$ping==1,1,0)
datx$eve=ifelse(datx$ping==2,1,0)
datx$night=ifelse(datx$ping==3,1,0)

#Code days of the week
datx$day <- rep(1:7, each=4, length.out=nrow(datx))
# 1 = Thursday (9/14/2017)
datx$mon=ifelse(datx$day==5,1,0)
datx$tues=ifelse(datx$day==6,1,0)
datx$wed=ifelse(datx$day==7,1,0)
datx$thur=ifelse(datx$day==1,1,0)
datx$fri=ifelse(datx$day==2,1,0)
datx$sat=ifelse(datx$day==3,1,0)
datx$sun=ifelse(datx$day==4,1,0)

#Temporal variables
datx$linear=scale(datx$cumsumT)
datx$quad=datx$linear^2
datx$cub=datx$linear^3
datx$cos24=cos(((2*pi)/24)*datx$cumsumT)
datx$sin24=sin(((2*pi)/24)*datx$cumsumT)
datx$cos12=cos(((2*pi)/12)*datx$cumsumT)
datx$sin12=sin(((2*pi)/12)*datx$cumsumT)

## Set variables forward in time
shift<-function(x,shift_by){
  stopifnot(is.numeric(shift_by))
  stopifnot(is.numeric(x))
  
  if (length(shift_by)>1)
    return(sapply(shift_by,shift, x=x))
  
  out<-NULL
  abs_shift_by=abs(shift_by)
  if (shift_by > 0 )
    out<-c(tail(x,-abs_shift_by),rep(NA,abs_shift_by))
  else if (shift_by < 0 )
    out<-c(rep(NA,abs_shift_by), head(x,-abs_shift_by))
  else
    out<-x
  out
}

datx$cigfw=shift(datx$cigs,1)
datx$cigbinfw=ifelse(datx$cigfw>=1,1,0)
datx$cigHfw=shift(datx$cigH,1)

datx$mornfw=shift(datx$morning,1)
datx$midfw=shift(datx$midday,1)
datx$evefw=shift(datx$eve,1)
datx$nightfw=shift(datx$night,1)

datx$monfw=shift(datx$mon,1)
datx$tuesfw=shift(datx$tues,1)
datx$wedfw=shift(datx$wed,1)
datx$thursfw=shift(datx$thur,1)
datx$frifw=shift(datx$fri,1)
datx$satfw=shift(datx$sat,1)
datx$sunfw=shift(datx$sun,1)

describe(datx)
colnames(datx)

## Create filter to mark cases with missing data
datx$filter=ifelse(!complete.cases(datx[,c(3:32,62)]),1,0)

## Remove NAs, suppress row names
daty=subset(datx,filter==0)
row.names(daty)<- NULL
nrow(daty)
#101

#Required packages
library(glmnet)
library(psych)
library(Hmisc)
library(party)
library(e1071)
library(pROC)

######################################################################
#################### Prediction Models ###############################
######################################################################

daty$even=seq(0,(nrow(daty)-1),1)
plot(daty$cigs~daty$even,type='o')
plot(daty$cigbinfw~daty$even,type='o')
plot(daty$cigHfw~daty$even,type='o')
nrow(daty)
#101

plot(daty$cigbinfw[1:76]~daty$even[1:76],type='o')
plot(daty$cigbinfw[77:101]~daty$even[77:101],type='o')

dat1=daty[1:76,]
dat2=daty[77:101,]

################################################################
#################### Elastic Net ###############################
################################################################

psych::describe(daty)

#Input matrices for GLMNET
mat1=as.matrix(dat1[,c(3,5:32,40,66:68,70:75,58:61)]) #yes/no
mat2=as.matrix(dat2[,c(3,5:32,40,66:68,70:75,58:61)])

#GLMNET
set.seed(1)
tmod1=cv.glmnet(mat1,dat1$cigbinfw,family='binomial',standardize=TRUE,alpha=.75,type.measure='mse')
coef1=coef(tmod1, s = "lambda.min")
coef1
#craving        0.0095926828
#enjoy.last     0.0200021412
#irritable     -0.0051991036
#down           0.0152931343
#stressed      -0.0102400872
#calm           0.0238804327
#happy          0.0150649531
#nervous       -0.0006670405
#hurt.health   -0.0127008413
#motivated     -0.0586202556
#pos.expect     0.0160366667
#ashamed       -0.0195735586
#could.quit    -0.0197473399
#delaygr       -0.0056989153
#comfortable    0.0042877387
#pos.social     0.0089828681
#midfw         -0.2977535915
#sunfw          0.7033677099
#cos24          .           
#sin24          0.6935538703 

#Training model(s)
mlpred1=predict.cv.glmnet(tmod1, newx=mat1, s = "lambda.min", type = "link")
dat1$netpred=as.numeric(mlpred1)
somers2(dat1$netpred,dat1$cigbinfw)[1]
#AUC = 0.98

#Testing model(s)
mlpred2=predict.cv.glmnet(tmod1, newx=mat2, s = "lambda.min", type = "link")
dat2$netpred=as.numeric(mlpred2)
somers2(dat2$netpred,dat2$cigbinfw)[1]
#AUC = 0.96

coords((roc(dat2$cigbinfw~dat2$netpred)),"best", ret=c("threshold", "specificity", "sensitivity"))
#  threshold specificity sensitivity 
# -0.6648110   0.8823529   1.0000000 
auc(roc(dat2$cigbinfw~dat2$netpred))
#0.96

#GLM model
#Training model
lm1=glm(cigbinfw~craving+enjoy.last+irritable+down+stressed+calm+happy+nervous+hurt.health+motivated+pos.expect+
          ashamed+could.quit+delaygr+comfortable+pos.social+midfw+sunfw+cos24+sin24,dat1,family='binomial')
somers2(predict(lm1),dat1$cigbinfw)[1]
#AUC = 1.00

#Testing model(s), Time 2
predfw <- predict(lm1, newdata = dat2)
somers2(predfw,dat2$cigbinfw)[1]
#AUC = 0.88

coords((roc(dat2$cigbinfw~predfw)),"best", ret=c("threshold", "specificity", "sensitivity"))
#  threshold specificity sensitivity 
# 16.9351963   0.8823529   0.7500000 
auc(roc(dat2$cigbinfw~predfw))
#0.88

################################################################
#################### Naive Bayes ###############################
################################################################

########################################################
### Naive Bayes with Random forest feature selection ###
########################################################

#Random Forest Feature Selection
nbdat=dat1[,c(63,3,5:32,40,66:68,70:75,58:61)]
nbdat$cigbinfw=as.factor(nbdat$cigbinfw)
set.seed(1)
cf <- cforest(cigbinfw ~ ., data=nbdat, control=cforest_unbiased(mtry=2,ntree=50))
set.seed(1)
imp=varimpAUC(cf)
imp[order(imp)]
print(imp>0)

#Random Forest data subsets
t1=nbdat[,-1]
newdat1 <- t1[, (imp>0)]

t2=dat2[,c(3,5:32,40,66:68,70:75,58:61)]
newdat2 <- t2[, (imp>0)]

#Naive Bayes with RF-selected data
rfnb=naiveBayes(newdat1,nbdat$cigbinfw)
rfnbpred=predict(rfnb,newdat2,type='raw')
somers2(rfnbpred[,2],dat2$cigbinfw)[1]
#0.98

coords((roc(dat2$cigbinfw~rfnbpred[,2])),"best", ret=c("threshold", "specificity", "sensitivity"))
#  threshold specificity sensitivity 
# 0.04577197  0.88235294  1.00000000 
auc(roc(dat2$cigbinfw~rfnbpred[,2]))
#0.98

########################################################
############ Naive Bayes with Complete Data ############
########################################################

nb=naiveBayes(mat1,dat1$cigbinfw)
nbpred=predict(nb,mat2,type='raw')
somers2(nbpred[,2],dat2$cigbinfw)[1]
#0.97

coords((roc(dat2$cigbinfw~nbpred[,2])),"best", ret=c("threshold", "specificity", "sensitivity"))
#  threshold specificity sensitivity 
# 0.01454714  0.88235294  1.00000000  
auc(roc(dat2$cigbinfw~nbpred[,2]))
#0.97

